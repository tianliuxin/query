from pandas.io.api import read_sql, read_csv, read_clipboard, read_excel, read_json
from pandas.core.api import DataFrame,Series

create_df = DataFrame
create_ts = Series